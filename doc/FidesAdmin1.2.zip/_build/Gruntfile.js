module.exports = function(grunt) {
 
    // Project configuration.
    grunt.initConfig({
 
        //Read the package.json (optional)
        pkg: grunt.file.readJSON('package.json'),
 
        // Metadata.
        meta: {
            basePath: '../',

            assets_build: '../_assets/',
            assets_production: '../production/assets/',
            assets_documentation: '../documentation/assets/',

            js_build: '../_assets/js/',
            js_production: '../production/assets/js/',

            css_build: '../_assets/css/',
            css_production: '../production/assets/css/',

            themes_build: '../_assets/themes/',
            themes_production: '../production/assets/themes/',
        },
 
        banner: '/*! <%= pkg.name %> - v<%= pkg.version %> ',
 
        concat: {

            options: {},

            coreJS: {

                src: [
                        '<%= meta.js_build %>core/jquery.1.10.2.js',
                        '<%= meta.js_build %>core/jquery.ui.core.js',
                        '<%= meta.js_build %>core/jquery.ui.widget.js',
                        '<%= meta.js_build %>core/d3.js',
                        '<%= meta.js_build %>core/jquery.ui.mouse.js',
                        '<%= meta.js_build %>core/jquery.ui.position.js',
                        '<%= meta.js_build %>core/jquery.ui.touch-punch.js',
                        '<%= meta.js_build %>core/jquery.cookie.js',
                    ],

                dest: '<%= meta.js_production %>aui-core.js'

            },

            interactionsJS: {

                src: [
                        '<%= meta.js_build %>/interactions/*.js',
                    ],

                dest: '<%= meta.js_production %>aui-interactions.js'

            },

            widgetsJS: {

                src: [
                        '<%= meta.js_build %>/widgets/*.js',
                        '!<%= meta.js_build %>/widgets/charts-justgage.js',
                        '!<%= meta.js_build %>/widgets/charts-morris.js',
                        '!<%= meta.js_build %>/widgets/other-gmaps.js',
                        '!<%= meta.js_build %>/widgets/other-vectormaps.js',
                        '!<%= meta.js_build %>/widgets/other-inputmask.js',
                    ],

                dest: '<%= meta.js_production %>aui-widgets.js'

            },

            demoJS: {

                src: [
                        '<%= meta.js_build %>/demo/*.js',
                        '!<%= meta.js_build %>demo/charts-justgage-demo.js',
                        '!<%= meta.js_build %>demo/xcharts-demo.js',
                        '!<%= meta.js_build %>demo/charts-morris-demo.js',
                    ],

                dest: '<%= meta.js_production %>aui-demo.js'

            },

            allScripts: {

                src: ['<%= meta.js_production %>aui-core.js', '<%= meta.js_production %>aui-interactions.js', '<%= meta.js_production %>aui-widgets.js', '<%= meta.js_production %>aui-demo.js'],
                dest: '<%= meta.js_production %>aui-production.js'
            },

            elementsCSS: {
                src: [
                        '<%= meta.css_build %>/**/*.css',
                        '!../_assets/css/elements/icons-ie7.css',
                        '!../_assets/css/components/calendar.css',
                        // '!../_assets/css/widgets/theme-switcher.css'
                    ],
                dest: '<%= meta.css_production %>app-production.css'
            },
            helpersCSS: {
                src: [
                        '<%= meta.css_build %>helpers/*.css'
                    ],
                dest: '<%= meta.css_production %>app-helpers.css'
            },

        },

        uglify: {

            options:{
                
            },

            dynamic_mappings: {

              files: [
                {
                  expand: true,
                  cwd: '<%= meta.js_build %>',
                  src: ['**/*.js'],
                  dest: '<%= meta.js_production %>minified/',
                  ext: '.min.js',
                },
              ],

            },

            static_mappings: {
              files: [
                {src: '<%= meta.js_production %>aui-production.js', dest: '<%= meta.js_production %>minified/aui-production.min.js'},
                {src: '<%= meta.js_production %>aui-core.js', dest: '<%= meta.js_production %>minified/aui-core.min.js'},
                {src: '<%= meta.js_production %>aui-demo.js', dest: '<%= meta.js_production %>minified/aui-demo.min.js'},
                {src: '<%= meta.js_production %>aui-interactions.js', dest: '<%= meta.js_production %>minified/aui-interactions.min.js'},
                {src: '<%= meta.js_production %>aui-widgets.js', dest: '<%= meta.js_production %>minified/aui-widgets.min.js'},
              ],
            }

        },

        cssmin: {

            minify_each: {
                expand: true,
                cwd: '<%= meta.css_build %>',
                src: ['**/*.css'],
                dest: '<%= meta.css_production %>minified/',
                ext: '.min.css'
            },
            minify_themes: {
                expand: true,
                cwd: '<%= meta.themes_build %>',
                src: ['**/*.css'],
                dest: '<%= meta.themes_production %>/minified',
                ext: '.min.css'
            },
            minify_all: {
                src: '<%= meta.css_production %>app-production.css',
                dest: '<%= meta.css_production %>minified/aui-production.min.css',
            },
            minify_helpers: {
                src: '<%= meta.css_production %>app-helpers.css',
                dest: '<%= meta.css_production %>minified/aui-helpers.min.css',
            },

        },

        includes: {
          generate_demo: {
            cwd: '../_content',
            src: '*.html',
            dest: '../production/',
            options: {
              banner: '<!-- AUI Framework -->\n'
            }
          },
          generate_documentation: {
            cwd: '../_content',
            src: '*.html',
            dest: '../documentation/',
            options: {
              banner: '<!-- AUI Documentation -->\n'
            }
          },
        },

        dom_munger: {
            remove_1: {
              options: {
                remove: '.rm-from-production',
                update: {selector:'#page-wrapper',attribute:'class',value:'demo-example'},
              },
              src: '../production/*.html',
            },
            remove_2: {
              options: {
                remove: '.user-profile',
                text: {selector:'#header-logo',text:'Documentation'},
              },
              src: '../documentation/*.html',
            },
            remove_3: {
              options: {
                remove: '#sidebar-search',
              },
              src: '../documentation/*.html',
            },
            remove_4: {
              options: {
                remove: '#page-breadcrumb-wrapper',
              },
              src: '../documentation/*.html',
            },
            remove_5: {
              options: {
                remove: '#page-header .dropdown',
              },
              src: '../documentation/*.html',
            },
            
        },

        copy: {
          fonts: {
            files: [
                {expand: true, cwd: '<%= meta.assets_build %>fonts', src: ['**'], dest: '<%= meta.assets_production %>fonts'}, 
            ]
          },
          ckeditor: {
            files: [
                {expand: true, cwd: '<%= meta.assets_build %>ckeditor', src: ['**'], dest: '<%= meta.assets_production %>ckeditor'}, 
            ]
          },
          vectormaps: {
            files: [
                {expand: true, cwd: '<%= meta.assets_build %>vector-maps', src: ['**'], dest: '<%= meta.assets_production %>vector-maps'}, 
            ]
          },
          multiupload: {
            files: [
                {expand: true, cwd: '<%= meta.assets_build %>multiupload', src: ['**'], dest: '<%= meta.assets_production %>multiupload'}, 
            ]
          },
          multiupload_server: {
            files: [
                {expand: true, cwd: '../_content/server', src: ['**'], dest: '../production/server'}, 
            ]
          },
          images: {
            files: [
                {expand: true, cwd: '<%= meta.assets_build %>images', src: ['**'], dest: '<%= meta.assets_production %>images'}, 
            ]
          },
          themes: {
            files: [
                {expand: true, cwd: '<%= meta.assets_build %>themes', src: ['**'], dest: '<%= meta.assets_production %>themes'}, 
            ]
          },
          docs_assets: {
            files: [
                {expand: true, cwd: '<%= meta.assets_production %>', src: ['**'], dest: '<%= meta.assets_documentation %>'}, 
            ]
          },
          docs_index: {
            src: '../documentation/index_documentation.html',
            dest: '../documentation/index.html',
          },
        },

    });
 
    // Plugins
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-dom-munger');
    grunt.loadNpmTasks('grunt-includes');
    // grunt.loadNpmTasks('grunt-cleanx');
 
    // Default task
    grunt.registerTask('default', ['concat', 'uglify', 'cssmin', 'includes', 'dom_munger', 'copy']);
    grunt.registerTask('dev', ['includes', 'dom_munger', 'copy']);
 
};